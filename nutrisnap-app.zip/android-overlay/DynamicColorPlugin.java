package com.nutrisnap.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.view.Window;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Liefert die Material-You-Farbpaletten (Hintergrundbild-Farben) von Android 12+
 * an die Web-Oberfläche und färbt Status- und Navigationsleiste passend ein.
 */
@CapacitorPlugin(name = "DynamicColor")
public class DynamicColorPlugin extends Plugin {

    private static final int[] ACCENT1 = {
        android.R.color.system_accent1_0, android.R.color.system_accent1_10, android.R.color.system_accent1_50,
        android.R.color.system_accent1_100, android.R.color.system_accent1_200, android.R.color.system_accent1_300,
        android.R.color.system_accent1_400, android.R.color.system_accent1_500, android.R.color.system_accent1_600,
        android.R.color.system_accent1_700, android.R.color.system_accent1_800, android.R.color.system_accent1_900,
        android.R.color.system_accent1_1000 };
    private static final int[] ACCENT2 = {
        android.R.color.system_accent2_0, android.R.color.system_accent2_10, android.R.color.system_accent2_50,
        android.R.color.system_accent2_100, android.R.color.system_accent2_200, android.R.color.system_accent2_300,
        android.R.color.system_accent2_400, android.R.color.system_accent2_500, android.R.color.system_accent2_600,
        android.R.color.system_accent2_700, android.R.color.system_accent2_800, android.R.color.system_accent2_900,
        android.R.color.system_accent2_1000 };
    private static final int[] ACCENT3 = {
        android.R.color.system_accent3_0, android.R.color.system_accent3_10, android.R.color.system_accent3_50,
        android.R.color.system_accent3_100, android.R.color.system_accent3_200, android.R.color.system_accent3_300,
        android.R.color.system_accent3_400, android.R.color.system_accent3_500, android.R.color.system_accent3_600,
        android.R.color.system_accent3_700, android.R.color.system_accent3_800, android.R.color.system_accent3_900,
        android.R.color.system_accent3_1000 };
    private static final int[] NEUTRAL1 = {
        android.R.color.system_neutral1_0, android.R.color.system_neutral1_10, android.R.color.system_neutral1_50,
        android.R.color.system_neutral1_100, android.R.color.system_neutral1_200, android.R.color.system_neutral1_300,
        android.R.color.system_neutral1_400, android.R.color.system_neutral1_500, android.R.color.system_neutral1_600,
        android.R.color.system_neutral1_700, android.R.color.system_neutral1_800, android.R.color.system_neutral1_900,
        android.R.color.system_neutral1_1000 };
    private static final int[] NEUTRAL2 = {
        android.R.color.system_neutral2_0, android.R.color.system_neutral2_10, android.R.color.system_neutral2_50,
        android.R.color.system_neutral2_100, android.R.color.system_neutral2_200, android.R.color.system_neutral2_300,
        android.R.color.system_neutral2_400, android.R.color.system_neutral2_500, android.R.color.system_neutral2_600,
        android.R.color.system_neutral2_700, android.R.color.system_neutral2_800, android.R.color.system_neutral2_900,
        android.R.color.system_neutral2_1000 };

    private JSArray tones(Context c, int[] ids) {
        JSArray a = new JSArray();
        for (int id : ids) {
            int col = c.getResources().getColor(id, c.getTheme());
            a.put(String.format("#%06X", 0xFFFFFF & col));
        }
        return a;
    }

    @PluginMethod
    public void get(PluginCall call) {
        Context c = getContext();
        JSObject o = new JSObject();
        boolean dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
            == Configuration.UI_MODE_NIGHT_YES;
        o.put("dark", dark);
        boolean supported = Build.VERSION.SDK_INT >= 31;
        o.put("supported", supported);
        if (supported) {
            o.put("accent1", tones(c, ACCENT1));
            o.put("accent2", tones(c, ACCENT2));
            o.put("accent3", tones(c, ACCENT3));
            o.put("neutral1", tones(c, NEUTRAL1));
            o.put("neutral2", tones(c, NEUTRAL2));
        }
        call.resolve(o);
    }

    @PluginMethod
    public void setBars(PluginCall call) {
        final String color = call.getString("color", "#000000");
        final boolean darkIcons = call.getBoolean("darkIcons", false);
        getActivity().runOnUiThread(() -> {
            try {
                Window w = getActivity().getWindow();
                int col = Color.parseColor(color);
                w.setStatusBarColor(col);
                w.setNavigationBarColor(col);
                WindowInsetsControllerCompat ic = WindowCompat.getInsetsController(w, w.getDecorView());
                ic.setAppearanceLightStatusBars(darkIcons);
                ic.setAppearanceLightNavigationBars(darkIcons);
            } catch (Exception ignored) { }
        });
        call.resolve();
    }
}
