(() => {
'use strict';

/* ---------- Konstanten ---------- */
const KEY = 'nutrisnap.v1';
const DEFAULT_MODEL = 'gemini-4-argon';
const MEALS = [['breakfast', 'Frühstück'], ['lunch', 'Mittagessen'], ['snack', 'Snack'], ['dinner', 'Abendessen']];
const NUTS = [
  ['kcal', 'Kalorien', 'kcal'], ['protein', 'Eiweiß', 'g'], ['carbs', 'Kohlenhydrate', 'g'], ['fat', 'Fett', 'g'],
  ['fiber', 'Ballaststoffe', 'g'], ['sugar', 'Zucker', 'g'], ['sat_fat', 'Gesättigte Fettsäuren', 'g'],
  ['sodium', 'Natrium', 'mg'], ['potassium', 'Kalium', 'mg'], ['calcium', 'Calcium', 'mg'], ['iron', 'Eisen', 'mg'],
  ['magnesium', 'Magnesium', 'mg'], ['zinc', 'Zink', 'mg'], ['vit_a', 'Vitamin A', 'µg'], ['vit_c', 'Vitamin C', 'mg'],
  ['vit_d', 'Vitamin D', 'µg'], ['vit_b12', 'Vitamin B12', 'µg']
];
const MICROS = NUTS.slice(4);
const WD = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
const MON = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];

/* ---------- Helfer ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const r0 = v => Math.round(v);
const r1 = v => Math.round(v * 10) / 10;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clone = o => JSON.parse(JSON.stringify(o));
const pad = n => String(n).padStart(2, '0');
const dkey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const mealName = id => (MEALS.find(m => m[0] === id) || [0, id])[1];
const fmt = (v, u) => (u === 'kcal' || v >= 100 ? r0(v) : r1(v)) + ' ' + u;

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

/* ---------- Speicher ---------- */
function loadState() {
  let s = {};
  try { s = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { s = {}; }
  return {
    settings: Object.assign({ apiKey: '', model: DEFAULT_MODEL, goal: 2000 }, s.settings || {}),
    library: Array.isArray(s.library) ? s.library : [],
    diary: Array.isArray(s.diary) ? s.diary : []
  };
}
let state = loadState();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); }
  catch (e) { toast('Speichern fehlgeschlagen (Speicher voll?)'); }
}

const ui = { tab: 'home', date: dkey(new Date()), sub: null, chartDays: 7, models: [] };
let draft = null;

/* ---------- Nährwert-Rechnung ---------- */
const zero = () => Object.fromEntries(NUTS.map(n => [n[0], 0]));
function itemVals(it) {
  const f = num(it.grams) / 100, o = {};
  for (const [k] of NUTS) o[k] = (it.p100 && it.p100[k] || 0) * f;
  return o;
}
function sum(items) {
  const t = zero();
  for (const it of items) { const v = itemVals(it); for (const k in t) t[k] += v[k]; }
  return t;
}
const dayEntries = k => state.diary.filter(e => e.date === k);
const dayTotals = k => sum(dayEntries(k).flatMap(e => e.items));
function itemFromAI(r) {
  const g = num(r.grams) > 0 ? num(r.grams) : 100, p = {};
  for (const [k] of NUTS) p[k] = Math.max(0, num(r[k])) * 100 / g;
  return { id: uid(), name: String(r.name || 'Unbekannt').slice(0, 80), grams: Math.round(g), p100: p };
}
function goals() {
  const g = num(state.settings.goal) || 2000;
  return { kcal: g, protein: g * 0.25 / 4, carbs: g * 0.5 / 4, fat: g * 0.25 / 9 };
}

/* ---------- Bibliothek ---------- */
function upsertFood(it) {
  const n = it.name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'food' && l.name.toLowerCase() === n);
  if (ex) { ex.items = [Object.assign(clone(it), { id: ex.items[0].id })]; ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'food', name: it.name.trim(), items: [clone(it)], used: 1, ts: Date.now() });
}
function upsertMeal(name, items) {
  const n = name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'meal' && l.name.toLowerCase() === n);
  if (ex) { ex.items = clone(items); ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'meal', name: name.trim(), items: clone(items), used: 1, ts: Date.now() });
}
function searchLibrary(q) {
  q = (q || '').trim().toLowerCase();
  return state.library
    .filter(l => !q || l.name.toLowerCase().includes(q))
    .sort((a, b) => (b.used || 0) - (a.used || 0) || a.name.localeCompare(b.name));
}
function libRow(l, attr) {
  const t = sum(l.items), g = l.items.reduce((a, i) => a + num(i.grams), 0);
  const sub = l.type === 'meal' ? l.items.length + ' Zutaten' : r0(g) + ' g';
  return `<button class="libitem" ${attr}="${l.id}"><div class="t"><b>${esc(l.name)}</b><span>${sub} · ${r0(t.kcal)} kcal · E ${r0(t.protein)} · K ${r0(t.carbs)} · F ${r0(t.fat)}</span></div>${l.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}</button>`;
}

/* ---------- Foto ---------- */
function loadImage(src) {
  return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
}
async function shrink(dataUrl, max, q) {
  const img = await loadImage(dataUrl);
  const s = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.width * s)); c.height = Math.max(1, Math.round(img.height * s));
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', q);
}
function fileToDataUrl(file) {
  return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
}
async function pickPhoto(source) {
  const cap = window.Capacitor;
  const cam = cap && cap.Plugins && cap.Plugins.Camera;
  if (cam && cap.isNativePlatform && cap.isNativePlatform()) {
    try {
      const r = await cam.getPhoto({ quality: 85, resultType: 'dataUrl', source: source === 'camera' ? 'CAMERA' : 'PHOTOS', width: 1600, correctOrientation: true });
      return r.dataUrl;
    } catch (e) {
      if (/cancel/i.test(String(e && (e.message || e)))) return null;
      console.warn('Camera plugin failed, falling back', e);
    }
  }
  return new Promise(resolve => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*';
    if (source === 'camera') inp.setAttribute('capture', 'environment');
    inp.onchange = async () => resolve(inp.files[0] ? await fileToDataUrl(inp.files[0]) : null);
    inp.click();
  });
}

/* ---------- Gemini ---------- */
const API = 'https://generativelanguage.googleapis.com/v1beta/';
function buildPrompt(text, hasImage) {
  return `Du bist ein erfahrener Ernährungsberater. Analysiere ${hasImage ? 'das Foto der Mahlzeit' : 'die Beschreibung der Mahlzeit'}${hasImage && text ? ' und die Angabe des Nutzers' : ''}.
${text ? 'Angabe des Nutzers (hat Vorrang, v. a. bei Mengen und Zutaten): "' + text + '"\n' : ''}Zerlege die Mahlzeit in die wichtigsten Bestandteile (maximal 8) und schätze realistische Portionsgrößen in Gramm.
Gib die Nährwerte jeweils für die gesamte geschätzte Portion dieses Bestandteils an (NICHT pro 100 g).
Antworte ausschließlich mit JSON in genau diesem Format, Namen auf Deutsch:
{"items":[{"name":"","grams":0,"kcal":0,"protein":0,"carbs":0,"fat":0,"fiber":0,"sugar":0,"sat_fat":0,"sodium":0,"potassium":0,"calcium":0,"iron":0,"magnesium":0,"zinc":0,"vit_a":0,"vit_c":0,"vit_d":0,"vit_b12":0}]}
Einheiten: kcal; protein, carbs, fat, fiber, sugar, sat_fat in g; sodium, potassium, calcium, iron, magnesium, zinc, vit_c in mg; vit_a, vit_d, vit_b12 in µg.
Ist kein Essen erkennbar, antworte {"items":[]}.`;
}
function parseJson(txt) {
  let s = String(txt || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  const j = JSON.parse(s);
  return Array.isArray(j) ? j : (j.items || []);
}
async function callGemini(imageDataUrl, text) {
  const { apiKey, model } = state.settings;
  if (!apiKey) { const e = new Error('NOKEY'); throw e; }
  const parts = [];
  if (imageDataUrl) parts.push({ inline_data: { mime_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } });
  parts.push({ text: buildPrompt(text, !!imageDataUrl) });
  const resp = await fetch(`${API}models/${encodeURIComponent(model || DEFAULT_MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: [{ parts }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } })
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error((data.error && data.error.message) || ('HTTP ' + resp.status));
  const cand = data.candidates && data.candidates[0];
  const txt = cand && cand.content && cand.content.parts ? cand.content.parts.map(p => p.text || '').join('') : '';
  if (!txt) throw new Error('Leere Antwort der KI');
  return parseJson(txt).map(itemFromAI);
}
async function loadModels() {
  if (!state.settings.apiKey) return toast('Erst den API-Key eintragen');
  try {
    const resp = await fetch(`${API}models?pageSize=200&key=${encodeURIComponent(state.settings.apiKey)}`);
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error && data.error.message || 'Fehler');
    ui.models = (data.models || [])
      .filter(m => /gemini/i.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent'))
      .map(m => m.name.replace(/^models\//, '')).sort().reverse();
    toast(ui.models.length + ' Modelle gefunden');
    render();
  } catch (e) { toast('Modelle laden fehlgeschlagen: ' + e.message); }
}

/* ---------- Rendering: Hauptansichten ---------- */
function render() {
  document.querySelectorAll('.navbtn').forEach(b => b.classList.toggle('on', b.dataset.tab === ui.tab));
  const v = $('#view');
  v.innerHTML = ({ home: renderHome, diary: renderDiary, charts: renderCharts, more: renderMore }[ui.tab])();
  if (ui.tab === 'home') {
    const p = $('#pages');
    if (p) p.addEventListener('scroll', () => {
      const i = Math.round(p.scrollLeft / p.clientWidth);
      document.querySelectorAll('.dots i').forEach((d, n) => d.classList.toggle('on', n === i));
    });
  }
  const s = $('#streak'); s.textContent = '';
  let streak = 0; for (let d = new Date(); ; d = addDays(d, -1)) { if (dayEntries(dkey(d)).length) streak++; else if (streak || dkey(d) !== dkey(new Date())) break; if (streak > 3650) break; }
  if (streak) s.textContent = '🔥 ' + streak;
}

function gauge(val, goal) {
  const L = Math.PI * 120, pct = Math.min(val / goal, 1), over = val > goal;
  const d = 'M30 150 A120 120 0 0 1 270 150';
  return `<div class="gwrap"><svg viewBox="0 0 300 165" class="gauge"><path d="${d}" class="g-bg"/><path d="${d}" class="g-fg ${over ? 'over' : ''}" stroke-dasharray="${L}" stroke-dashoffset="${L * (1 - pct)}"/></svg>
  <div class="gtext"><div class="big">${r0(val)}</div><div class="lbl">Kalorien gegessen</div></div></div>
  <div class="sub">${over ? r0(val - goal) + ' kcal über dem Ziel' : 'noch ' + r0(goal - val) + ' kcal bis ' + r0(goal)}</div>`;
}

function renderHome() {
  const k = ui.date, t = dayTotals(k), g = goals();
  const sel = parseKey(k), dow = (sel.getDay() + 6) % 7, mon = addDays(sel, -dow), today = dkey(new Date());
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(mon, i), kk = dkey(d);
    return `<button class="day ${kk === k ? 'sel' : ''}" data-a="date" data-date="${kk}"><small>${MON[d.getMonth()]} ${d.getDate()}</small><b>${WD[i]}</b></button>`;
  }).join('');
  const mac = [['protein', 'Eiweiß', g.protein, 'var(--p)'], ['carbs', 'Kohlenhydrate', g.carbs, 'var(--c)'], ['fat', 'Fett', g.fat, 'var(--f)']]
    .map(([id, l, goal, col]) => `<div class="macro"><b>${r0(t[id])} g</b><div class="bar"><i style="width:${Math.min(100, t[id] / goal * 100)}%;background:${col}"></i></div><span>${l}</span></div>`).join('');
  const micro = MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
  const perMeal = MEALS.map(([id, l]) => {
    const m = sum(dayEntries(k).filter(e => e.meal === id).flatMap(e => e.items));
    return `<div class="mealrow"><span>${l}</span><b>${r0(m.kcal)} kcal</b></div>`;
  }).join('');
  const meals = MEALS.map(([id, l]) => {
    const es = dayEntries(k).filter(e => e.meal === id).sort((a, b) => a.ts - b.ts);
    const kc = es.reduce((a, e) => a + sum(e.items).kcal, 0);
    return `<div class="meal"><div class="meal-head"><div><div class="meal-name">${l}</div>${es.length ? `<div class="meal-kcal">${r0(kc)} kcal</div>` : ''}</div>
      <button class="plus" data-a="add" data-meal="${id}" aria-label="${l} hinzufügen"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" stroke="#fff" stroke-width="2.8" stroke-linecap="round"/></svg></button></div>
      ${es.map(e => { const s = sum(e.items); return `<button class="entry" data-a="edit" data-id="${e.id}">${e.thumb ? `<img class="thumb" src="${e.thumb}">` : '<div class="thumb">🍽</div>'}<div class="t"><b>${esc(e.name)}</b><span>${r0(s.kcal)} kcal · E ${r0(s.protein)} · K ${r0(s.carbs)} · F ${r0(s.fat)}</span></div></button>`; }).join('')}</div>`;
  }).join('');
  return `${state.settings.apiKey ? '' : '<button class="banner" data-a="tab" data-tab="more">⚠️ Noch kein Gemini-API-Key hinterlegt – hier tippen und unter „Mehr“ eintragen.</button>'}
  <div class="week">${week}</div>
  <div class="pages" id="pages">
    <div class="page">${gauge(t.kcal, g.kcal)}<div class="macros">${mac}</div></div>
    <div class="page"><h3>Mikronährstoffe &amp; mehr</h3><div class="microgrid">${micro}</div></div>
    <div class="page"><h3>Kalorien pro Mahlzeit</h3>${perMeal}<div class="mealrow"><span>Ziel</span><b>${r0(g.kcal)} kcal</b></div></div>
  </div>
  <div class="dots"><i class="on"></i><i></i><i></i></div>
  <h2>${k === today ? 'Heutige Mahlzeiten' : 'Mahlzeiten am ' + sel.getDate() + '. ' + MON[sel.getMonth()]}</h2>${meals}`;
}

function renderDiary() {
  const days = new Set(state.diary.map(e => e.date)); days.add(dkey(new Date()));
  const list = [...days].sort().reverse().map(k => {
    const t = dayTotals(k), d = parseKey(k), n = dayEntries(k).length;
    return `<button class="libitem" data-a="date" data-date="${k}" data-goto="home"><div class="t"><b>${WD[(d.getDay() + 6) % 7]}, ${d.getDate()}. ${MON[d.getMonth()]} ${d.getFullYear()}</b><span>${n} Einträge · E ${r0(t.protein)} g · K ${r0(t.carbs)} g · F ${r0(t.fat)} g</span></div><b>${r0(t.kcal)} kcal</b></button>`;
  }).join('');
  return `<h2>Tagebuch</h2>${list}`;
}

function renderCharts() {
  const n = ui.chartDays, g = goals();
  const days = Array.from({ length: n }, (_, i) => addDays(new Date(), i - n + 1));
  const data = days.map(d => ({ d, t: dayTotals(dkey(d)), has: dayEntries(dkey(d)).length > 0 }));
  const max = Math.max(g.kcal * 1.15, ...data.map(x => x.t.kcal));
  const W = 320, H = 170, bw = W / n, y = v => H - 18 - (v / max) * (H - 30);
  const bars = data.map((x, i) => {
    const h = H - 18 - y(x.t.kcal);
    const lbl = n <= 7 ? WD[(x.d.getDay() + 6) % 7] : (i % 5 === 0 ? x.d.getDate() : '');
    return `<rect x="${i * bw + bw * 0.15}" y="${y(x.t.kcal)}" width="${bw * 0.7}" height="${Math.max(h, 0)}" rx="${Math.min(6, bw * .2)}" fill="${x.t.kcal > g.kcal ? 'var(--red)' : 'var(--accent)'}"/><text x="${i * bw + bw / 2}" y="${H - 3}" fill="#8393ae" font-size="11" text-anchor="middle">${lbl}</text>`;
  }).join('');
  const withData = data.filter(x => x.has), c = withData.length || 1;
  const avg = k => withData.reduce((a, x) => a + x.t[k], 0) / c;
  const kp = avg('protein') * 4, kc = avg('carbs') * 4, kf = avg('fat') * 9, ks = (kp + kc + kf) || 1;
  const micro = MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(avg(id), u)}</span></div>`).join('');
  return `<h2>Charts</h2><div class="chips"><button class="pill ${n === 7 ? 'on' : ''}" data-a="range" data-n="7">7 Tage</button><button class="pill ${n === 30 ? 'on' : ''}" data-a="range" data-n="30">30 Tage</button></div>
  <div class="card"><h3>Kalorien pro Tag (Ziel ${r0(g.kcal)})</h3><svg viewBox="0 0 ${W} ${H}" width="100%"><line x1="0" x2="${W}" y1="${y(g.kcal)}" y2="${y(g.kcal)}" stroke="#43c27a" stroke-dasharray="4 4"/>${bars}</svg></div>
  <div class="card"><h3>Ø pro Tag (${withData.length} Tage mit Einträgen)</h3><div class="gtext" style="position:static"><div class="big" style="font-size:40px">${r0(avg('kcal'))} <small style="font-size:16px;color:var(--mute)">kcal</small></div></div>
  <div class="stack"><i style="width:${kp / ks * 100}%;background:var(--p)"></i><i style="width:${kc / ks * 100}%;background:var(--c)"></i><i style="width:${kf / ks * 100}%;background:var(--f)"></i></div>
  <div class="legend"><span><i style="background:var(--p)"></i>Eiweiß ${r0(avg('protein'))} g</span><span><i style="background:var(--c)"></i>Kohlenhydrate ${r0(avg('carbs'))} g</span><span><i style="background:var(--f)"></i>Fett ${r0(avg('fat'))} g</span></div></div>
  <details><summary>Ø Mikronährstoffe</summary><div class="microgrid" style="margin-top:10px">${micro}</div></details>`;
}

function renderMore() {
  if (ui.sub === 'library') {
    return `<div class="ovhead"><button class="x" data-a="sub" data-sub="">←</button><h1>Bibliothek</h1></div>
    <input id="libq" data-i="libq" placeholder="Suchen…" style="margin-bottom:12px"><div id="liblist">${libList('', 'manage')}</div>`;
  }
  const s = state.settings;
  const opts = ui.models.length ? `<select data-i="model-select">${ui.models.map(m => `<option ${m === s.model ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select>` : '';
  return `<h2>Einstellungen</h2>
  <label class="fld">Google-Gemini-API-Key</label><input type="password" data-i="set" data-f="apiKey" value="${esc(s.apiKey)}" placeholder="AIza…" autocomplete="off">
  <div class="muted" style="font-size:13px;margin-top:6px">Kostenlos erstellen unter aistudio.google.com/apikey. Der Key bleibt nur auf deinem Handy.</div>
  <label class="fld">Modell</label><input data-i="set" data-f="model" value="${esc(s.model)}" placeholder="${DEFAULT_MODEL}">${opts}
  <button class="btn ghost" data-a="models">Verfügbare Modelle laden</button>
  <label class="fld">Tagesziel Kalorien</label><input type="number" inputmode="numeric" data-i="set" data-f="goal" value="${esc(s.goal)}">
  <h2>Daten</h2>
  <button class="choice" data-a="sub" data-sub="library"><div class="ic">📚</div><div><b>Bibliothek</b><span>${state.library.length} gespeicherte Lebensmittel &amp; Gerichte</span></div></button>
  <button class="btn ghost" data-a="backup-copy">Backup in Zwischenablage kopieren</button>
  <button class="btn ghost" data-a="backup-paste">Backup einfügen / wiederherstellen</button>
  <p class="muted center" style="margin-top:24px;font-size:13px">NutriSnap 1.0 · KI-Werte sind Schätzungen</p>`;
}

function libList(q, mode) {
  const l = searchLibrary(q);
  if (!l.length) return `<p class="muted center" style="margin:30px 0">${state.library.length ? 'Nichts gefunden.' : 'Noch nichts gespeichert. Jede gespeicherte Mahlzeit füllt die Bibliothek automatisch.'}</p>`;
  return l.map(x => mode === 'manage'
    ? `<div class="libitem">${libRowInner(x)}<button class="del x" data-a="libdel" data-id="${x.id}" style="width:36px;height:36px;font-size:16px">✕</button></div>`
    : libRow(x, 'data-libadd')).join('');
}
function libRowInner(l) {
  const t = sum(l.items), g = l.items.reduce((a, i) => a + num(i.grams), 0);
  return `<div class="t"><b>${esc(l.name)}</b><span>${l.type === 'meal' ? l.items.length + ' Zutaten' : r0(g) + ' g'} · ${r0(t.kcal)} kcal</span></div>${l.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}`;
}

/* ---------- Hinzufügen-Flow (Overlay) ---------- */
function newDraft(meal) {
  return { stage: 'choose', meal, date: ui.date, items: [], photo: '', thumb: '', text: '', name: '', editId: null, append: false, saveMeal: false, mealName: '', libq: '', added: 0 };
}
function guessMeal() { const h = new Date().getHours(); return h < 10 ? 'breakfast' : h < 15 ? 'lunch' : h < 18 ? 'snack' : 'dinner'; }
function openOverlay() { $('#overlay').hidden = false; renderOverlay(); }
function closeOverlay() { $('#overlay').hidden = true; draft = null; render(); }

function mealChips() {
  return `<div class="chips">${MEALS.map(([id, l]) => `<button class="pill ${draft.meal === id ? 'on' : ''}" data-a="setmeal" data-meal="${id}">${l}</button>`).join('')}</div>`;
}
const head = (title, back) => `<div class="ovhead">${back ? `<button class="x" data-a="${back}">←</button>` : ''}<h1>${title}</h1><button class="x" data-a="close">✕</button></div>`;

function renderOverlay() {
  const d = draft, o = $('#overlay');
  if (!d) return;
  let h = '';
  if (d.stage === 'choose') {
    h = `${head('Mahlzeit hinzufügen')}${mealChips()}
    <button class="choice" data-a="cam"><div class="ic">📷</div><div><b>Foto aufnehmen</b><span>KI erkennt Essen &amp; Nährwerte</span></div></button>
    <button class="choice" data-a="gal"><div class="ic">🖼️</div><div><b>Aus Galerie wählen</b><span>vorhandenes Foto analysieren</span></div></button>
    <button class="choice" data-a="desc"><div class="ic">✍️</div><div><b>Beschreiben</b><span>z. B. „2 Spiegeleier mit Toast“</span></div></button>
    <button class="choice" data-a="lib"><div class="ic">📚</div><div><b>Aus Bibliothek</b><span>Gespeichertes suchen &amp; kombinieren</span></div></button>`;
  } else if (d.stage === 'photo') {
    h = `${head('Dein Foto', 'tochoose')}<img class="photo" src="${d.photo}">
    <label class="fld">Was hast du gegessen? (optional)</label>
    <textarea data-i="text" placeholder="z. B. Vollkornbrot mit Frischkäse, ca. 250 g Joghurt …">${esc(d.text)}</textarea>
    <div class="row"><button class="btn ghost" data-a="analyze" data-skip="1">Überspringen</button><button class="btn" data-a="analyze">Analysieren</button></div>`;
  } else if (d.stage === 'text') {
    h = `${head(d.append ? 'Zutat hinzufügen' : 'Mahlzeit beschreiben', d.append ? 'toreview' : 'tochoose')}
    <textarea data-i="text" placeholder="z. B. 2 Spiegeleier, 1 Scheibe Toast mit Butter, ein Glas Orangensaft" style="min-height:140px">${esc(d.text)}</textarea>
    <button class="btn" data-a="analyze" data-textonly="1">Analysieren</button>`;
  } else if (d.stage === 'loading') {
    h = `${head('Analysiere …')}<div class="spinner"></div><p class="center muted">Die KI schätzt Portionen und Nährwerte.</p>`;
  } else if (d.stage === 'library') {
    h = `${head('Bibliothek', d.items.length || d.editId ? 'toreview' : 'tochoose')}
    <input data-i="libq" placeholder="Suchen…" value="${esc(d.libq)}" style="margin-bottom:12px">
    <div id="liblist">${libList(d.libq, 'pick')}</div>
    <button class="btn" data-a="toreview" ${d.items.length ? '' : 'disabled'}>Fertig (${d.items.length} Zutaten)</button>`;
  } else if (d.stage === 'review') {
    const t = sum(d.items);
    h = `${head(d.editId ? 'Eintrag bearbeiten' : 'Ergebnis')}
    ${d.photo ? `<img class="photo" style="max-height:200px" src="${d.photo}">` : ''}
    ${mealChips()}
    <input data-i="name" placeholder="Name der Mahlzeit (optional)" value="${esc(d.name)}" style="margin-bottom:14px">
    <div id="items">${d.items.map((it, i) => itemHtml(it, i)).join('') || '<p class="muted center">Noch keine Zutaten.</p>'}</div>
    <div class="row"><button class="btn ghost" data-a="addtext">+ Zutat (KI)</button><button class="btn ghost" data-a="lib">+ Bibliothek</button></div>
    <div class="total" id="total">${totalHtml(t)}</div>
    <details><summary>Alle Nährstoffe</summary><div class="microgrid" id="micros" style="margin-top:10px">${microHtml(t)}</div></details>
    ${d.items.length > 1 ? `<label class="chk"><input type="checkbox" data-i="savemeal" ${d.saveMeal ? 'checked' : ''}><span>Als Gericht in der Bibliothek speichern</span></label>
    ${d.saveMeal ? `<input data-i="mealname" placeholder="Name des Gerichts" value="${esc(d.mealName || d.name)}">` : ''}` : ''}
    <button class="btn accent" data-a="save" ${d.items.length ? '' : 'disabled'}>Speichern</button>
    ${d.editId ? '<button class="btn danger" data-a="delentry">Eintrag löschen</button>' : ''}`;
  }
  o.innerHTML = `<div class="ov">${h}</div>`;
}
function itemHtml(it, i) {
  const v = itemVals(it);
  return `<div class="item"><div class="top"><input data-i="iname" data-idx="${i}" value="${esc(it.name)}"><input class="g" type="number" inputmode="decimal" data-i="igrams" data-idx="${i}" value="${r0(it.grams)}"><span class="muted">g</span><button class="del" data-a="idel" data-idx="${i}">✕</button></div>
  <div class="nums" id="in${i}">${itemNums(v)}</div></div>`;
}
const itemNums = v => `<span><b>${r0(v.kcal)}</b> kcal</span><span>E <b>${r0(v.protein)}</b></span><span>K <b>${r0(v.carbs)}</b></span><span>F <b>${r0(v.fat)}</b></span>`;
const totalHtml = t => `<div class="kc">${r0(t.kcal)} <small>kcal</small></div><div class="muted">Eiweiß ${r0(t.protein)} g · Kohlenhydrate ${r0(t.carbs)} g · Fett ${r0(t.fat)} g</div>`;
const microHtml = t => MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
function refreshTotals() {
  const t = sum(draft.items);
  const a = $('#total'); if (a) a.innerHTML = totalHtml(t);
  const b = $('#micros'); if (b) b.innerHTML = microHtml(t);
  draft.items.forEach((it, i) => { const e = $('#in' + i); if (e) e.innerHTML = itemNums(itemVals(it)); });
}

async function analyze(skip, textOnly) {
  const d = draft, text = skip ? '' : (d.text || '').trim();
  const useImage = !textOnly && d.photo && !d.append;
  if (textOnly && !text) return toast('Bitte etwas eingeben');
  const prev = d.stage;
  d.stage = 'loading'; renderOverlay();
  try {
    const items = await callGemini(useImage ? d.photo : null, text);
    if (!draft) return;
    if (!items.length) { d.stage = prev; renderOverlay(); return toast('Kein Essen erkannt – bitte beschreibe es kurz.'); }
    d.items = d.append ? d.items.concat(items) : items;
    if (!d.append && !d.name && text) d.name = '';
    d.append = false; d.text = ''; d.stage = 'review'; renderOverlay();
  } catch (e) {
    if (!draft) return;
    d.stage = prev; renderOverlay();
    if (e.message === 'NOKEY') toast('Bitte zuerst den API-Key unter „Mehr“ eintragen.');
    else toast('Fehler: ' + e.message);
  }
}
function saveDraft() {
  const d = draft;
  if (!d.items.length) return;
  const name = (d.name || '').trim() || d.items.map(i => i.name).join(', ').slice(0, 60);
  const entry = { id: d.editId || uid(), date: d.date, meal: d.meal, name, thumb: d.thumb || '', items: clone(d.items), ts: d.ts || Date.now() };
  const i = d.editId ? state.diary.findIndex(e => e.id === d.editId) : -1;
  if (i >= 0) state.diary[i] = entry; else state.diary.push(entry);
  d.items.forEach(upsertFood);
  if (d.saveMeal && d.items.length > 1) upsertMeal(d.mealName || name, d.items);
  save(); closeOverlay(); toast('Gespeichert');
}

/* ---------- Ereignisse ---------- */
const actions = {
  tab(el) { ui.tab = el.dataset.tab; ui.sub = null; render(); window.scrollTo(0, 0); },
  date(el) { ui.date = el.dataset.date; if (el.dataset.goto) ui.tab = el.dataset.goto; render(); window.scrollTo(0, 0); },
  range(el) { ui.chartDays = +el.dataset.n; render(); },
  sub(el) { ui.sub = el.dataset.sub || null; render(); },
  fab() { draft = newDraft(guessMeal()); openOverlay(); },
  add(el) { draft = newDraft(el.dataset.meal); openOverlay(); },
  edit(el) {
    const e = state.diary.find(x => x.id === el.dataset.id); if (!e) return;
    draft = Object.assign(newDraft(e.meal), { stage: 'review', date: e.date, items: clone(e.items), thumb: e.thumb, name: e.name, editId: e.id, ts: e.ts });
    openOverlay();
  },
  close() { closeOverlay(); },
  setmeal(el) { draft.meal = el.dataset.meal; renderOverlay(); },
  tochoose() { draft.stage = 'choose'; renderOverlay(); },
  toreview() { draft.append = false; draft.stage = draft.items.length || draft.editId ? 'review' : 'choose'; renderOverlay(); },
  async cam() { await photo('camera'); },
  async gal() { await photo('photos'); },
  desc() { draft.stage = 'text'; draft.append = false; renderOverlay(); },
  addtext() { draft.stage = 'text'; draft.append = true; draft.text = ''; renderOverlay(); },
  lib() { draft.stage = 'library'; renderOverlay(); },
  analyze(el) { analyze(!!el.dataset.skip, !!el.dataset.textonly); },
  idel(el) { draft.items.splice(+el.dataset.idx, 1); renderOverlay(); },
  save() { saveDraft(); },
  delentry() {
    if (!confirm('Eintrag wirklich löschen?')) return;
    state.diary = state.diary.filter(e => e.id !== draft.editId); save(); closeOverlay();
  },
  libdel(el) {
    if (!confirm('Aus der Bibliothek löschen?')) return;
    state.library = state.library.filter(l => l.id !== el.dataset.id); save(); render();
  },
  models() { loadModels(); },
  async 'backup-copy'() {
    try { await navigator.clipboard.writeText(JSON.stringify(state)); toast('Backup kopiert – z. B. in eine Notiz einfügen'); }
    catch (e) { toast('Kopieren nicht möglich'); }
  },
  'backup-paste'() {
    const t = prompt('Backup-Text hier einfügen (ersetzt alle aktuellen Daten):');
    if (!t) return;
    try {
      const s = JSON.parse(t);
      if (!Array.isArray(s.diary) || !Array.isArray(s.library)) throw new Error('x');
      state = Object.assign(loadStateFrom(s)); save(); render(); toast('Backup wiederhergestellt');
    } catch (e) { toast('Das war kein gültiges Backup'); }
  }
};
function loadStateFrom(s) {
  return { settings: Object.assign({ apiKey: '', model: DEFAULT_MODEL, goal: 2000 }, s.settings || {}), library: s.library, diary: s.diary };
}
async function photo(src) {
  const raw = await pickPhoto(src);
  if (!raw) return;
  try {
    draft.photo = await shrink(raw, 1024, 0.8);
    draft.thumb = await shrink(raw, 140, 0.6);
    draft.stage = 'photo'; renderOverlay();
  } catch (e) { toast('Foto konnte nicht geladen werden'); }
}

document.addEventListener('click', e => {
  const libadd = e.target.closest('[data-libadd]');
  if (libadd && draft) {
    const l = state.library.find(x => x.id === libadd.dataset.libadd);
    if (l) {
      l.items.forEach(it => draft.items.push(Object.assign(clone(it), { id: uid() })));
      l.used = (l.used || 0) + 1; save();
      toast('+ ' + l.name);
      renderOverlay();
    }
    return;
  }
  const el = e.target.closest('[data-a]');
  if (el && actions[el.dataset.a]) actions[el.dataset.a](el, e);
});
document.addEventListener('input', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (!i) return;
  if (i === 'text' && draft) draft.text = t.value;
  else if (i === 'name' && draft) draft.name = t.value;
  else if (i === 'mealname' && draft) draft.mealName = t.value;
  else if (i === 'iname' && draft) draft.items[+t.dataset.idx].name = t.value;
  else if (i === 'igrams' && draft) { draft.items[+t.dataset.idx].grams = num(t.value); refreshTotals(); }
  else if (i === 'libq') {
    if (draft) draft.libq = t.value;
    const l = $('#liblist'); if (l) l.innerHTML = libList(t.value, draft ? 'pick' : 'manage');
  }
  else if (i === 'set') {
    const f = t.dataset.f; state.settings[f] = f === 'goal' ? (num(t.value) || 2000) : t.value.trim(); save();
  }
});
document.addEventListener('change', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (i === 'savemeal' && draft) { draft.saveMeal = t.checked; renderOverlay(); }
  else if (i === 'model-select') { state.settings.model = t.value; save(); render(); toast('Modell: ' + t.value); }
});

window.__nutrisnap = { get state() { return state; }, get draft() { return draft; }, ui, render, callGemini, saveDraft, sum, actions, itemFromAI };
render();
})();
