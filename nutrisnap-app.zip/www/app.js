(() => {
'use strict';

/* ---------- Konstanten ---------- */
const KEY = 'nutrisnap.v1';
const THEME_KEY = 'nutrisnap.theme';
const DEFAULT_MODEL = 'gemini-2.5-flash';
const API = 'https://generativelanguage.googleapis.com/v1beta/';
const MEALS = [['breakfast', 'Frühstück', 'Frühstück'], ['lunch', 'Mittagessen', 'Mittag'], ['snack', 'Snack', 'Snack'], ['dinner', 'Abendessen', 'Abend']];
const NUTS = [
  ['kcal', 'Kalorien', 'kcal'], ['protein', 'Eiweiß', 'g'], ['carbs', 'Kohlenhydrate', 'g'], ['fat', 'Fett', 'g'],
  ['fiber', 'Ballaststoffe', 'g'], ['sugar', 'Zucker', 'g'], ['sat_fat', 'Gesättigte Fettsäuren', 'g'],
  ['sodium', 'Natrium', 'mg'], ['potassium', 'Kalium', 'mg'], ['calcium', 'Calcium', 'mg'], ['iron', 'Eisen', 'mg'],
  ['magnesium', 'Magnesium', 'mg'], ['zinc', 'Zink', 'mg'], ['vit_a', 'Vitamin A', 'µg'], ['vit_c', 'Vitamin C', 'mg'],
  ['vit_d', 'Vitamin D', 'µg'], ['vit_b12', 'Vitamin B12', 'µg']
];
const MICROS = NUTS.slice(4);
const WD = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
const WDL = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag'];
const MONL = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

/* ---------- Icons (Material Symbols, gefüllt) ---------- */
const ICONS = {
  add: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  settings: 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.488.488 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
  close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
  camera: 'M12 15.2a3.2 3.2 0 100-6.4 3.2 3.2 0 000 6.4zM9 2L7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z',
  image: 'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a.996.996 0 000-1.41l-2.34-2.34a.996.996 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  book: 'M21 5c-1.11-.35-2.33-.5-3.5-.5-1.95 0-4.05.4-5.5 1.5-1.45-1.1-3.55-1.5-5.5-1.5S2.45 4.9 1 6v14.65c0 .25.25.5.5.5.1 0 .15-.05.25-.05C3.1 20.45 5.05 20 6.5 20c1.95 0 4.05.4 5.5 1.5 1.35-.85 3.8-1.5 5.5-1.5 1.65 0 3.35.3 4.75 1.05.1.05.15.05.25.05.25 0 .5-.25.5-.5V6c-.6-.45-1.25-.75-2-1zm0 13.5c-1.1-.35-2.3-.5-3.5-.5-1.7 0-4.15.65-5.5 1.5V8c1.35-.85 3.8-1.5 5.5-1.5 1.2 0 2.4.15 3.5.5v11.5z',
  delete: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  check: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
  error: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z',
  left: 'M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z',
  right: 'M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z',
  food: 'M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z',
  fire: 'M13.5.67s.74 2.65.74 4.8c0 2.06-1.35 3.73-3.41 3.73-2.07 0-3.63-1.67-3.63-3.73l.03-.36C5.21 7.51 4 10.62 4 14c0 4.42 3.58 8 8 8s8-3.58 8-8C20 8.61 17.41 3.8 13.5.67zM11.71 19c-1.78 0-3.22-1.4-3.22-3.14 0-1.62 1.05-2.76 2.81-3.12 1.77-.36 3.6-1.21 4.62-2.58.39 1.29.59 2.65.59 4.04 0 2.65-2.15 4.8-4.8 4.8z',
  eye: 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z',
  sparkle: 'M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5zM19 15l-1.25 2.75L15 19l2.75 1.25L19 23l1.25-2.75L23 19l-2.75-1.25L19 15z'
};
const ic = n => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[n]}"/></svg>`;

/* ---------- Helfer ---------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return Number.isFinite(n) ? n : 0; };
const r0 = v => Math.round(v);
const r1 = v => Math.round(v * 10) / 10;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const clone = o => JSON.parse(JSON.stringify(o));
const pad = n => String(n).padStart(2, '0');
const dkey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const fmt = (v, u) => (u === 'kcal' || v >= 100 ? r0(v) : r1(v)) + ' ' + u;
const wdIndex = d => (d.getDay() + 6) % 7;

let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}

/* ---------- Speicher ---------- */
function loadState() {
  let s = {};
  try { s = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { s = {}; }
  return {
    settings: Object.assign({ apiKey: '', model: DEFAULT_MODEL, goal: 2000, keyOk: false }, s.settings || {}),
    library: Array.isArray(s.library) ? s.library : [],
    diary: Array.isArray(s.diary) ? s.diary : []
  };
}
let state = loadState();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); }
  catch (e) { toast('Speichern fehlgeschlagen (Speicher voll?)'); }
}

const ui = { date: dkey(new Date()), meal: null, models: [], key: { s: 'idle' }, showKey: false };
let draft = null;

/* ---------- Dynamische Farben (Material You) ---------- */
const T_IDX = { 0: 0, 10: 1, 50: 2, 100: 3, 200: 4, 300: 5, 400: 6, 500: 7, 600: 8, 700: 9, 800: 10, 900: 11, 1000: 12 };
function hex2rgb(h) { h = h.replace('#', ''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)); }
function mix(a, b, t) {
  const A = hex2rgb(a), B = hex2rgb(b);
  return '#' + A.map((v, i) => pad(Math.round(v + (B[i] - v) * t).toString(16))).join('');
}
const tone = (arr, t) => Array.isArray(arr) ? arr[T_IDX[t]] : (arr && arr[t]);
function setVars(o) {
  const st = document.documentElement.style;
  for (const k in o) st.setProperty('--' + k, o[k]);
}
async function applyPalette(t) {
  const dark = t && typeof t.dark === 'boolean' ? t.dark : window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.style.colorScheme = dark ? 'dark' : 'light';
  let surface = null;
  if (t && t.accent1 && t.neutral1 && tone(t.accent1, 600)) {
    const a = t.accent1, b = t.accent2, c = t.accent3, n = t.neutral1, v = t.neutral2;
    const P = dark ? {
      'primary': tone(a, 200), 'on-primary': tone(a, 800), 'primary-container': tone(a, 700), 'on-primary-container': tone(a, 100),
      'secondary': tone(b, 200), 'on-secondary': tone(b, 800), 'secondary-container': tone(b, 700), 'on-secondary-container': tone(b, 100),
      'tertiary': tone(c, 200), 'on-tertiary': tone(c, 800), 'tertiary-container': tone(c, 700), 'on-tertiary-container': tone(c, 100),
      'surface': mix(tone(n, 900), tone(n, 1000), .35), 'on-surface': tone(n, 100), 'on-surface-variant': tone(v, 200),
      'outline': tone(v, 500), 'outline-variant': tone(v, 700),
      'sc-lowest': tone(n, 1000), 'sc-low': tone(n, 900), 'sc': mix(tone(n, 900), tone(n, 800), .5), 'sc-high': tone(n, 800), 'sc-highest': tone(n, 700),
      'error': '#ffb4ab', 'error-container': '#93000a', 'on-error-container': '#ffdad6', 'inverse': tone(n, 100), 'on-inverse': tone(n, 800)
    } : {
      'primary': tone(a, 600), 'on-primary': tone(a, 0), 'primary-container': tone(a, 100), 'on-primary-container': tone(a, 900),
      'secondary': tone(b, 600), 'on-secondary': tone(b, 0), 'secondary-container': tone(b, 100), 'on-secondary-container': tone(b, 900),
      'tertiary': tone(c, 600), 'on-tertiary': tone(c, 0), 'tertiary-container': tone(c, 100), 'on-tertiary-container': tone(c, 900),
      'surface': tone(n, 10), 'on-surface': tone(n, 900), 'on-surface-variant': tone(v, 700),
      'outline': tone(v, 500), 'outline-variant': tone(v, 200),
      'sc-lowest': tone(n, 0), 'sc-low': tone(n, 50), 'sc': mix(tone(n, 50), tone(n, 100), .5), 'sc-high': tone(n, 100), 'sc-highest': tone(n, 200),
      'error': '#ba1a1a', 'error-container': '#ffdad6', 'on-error-container': '#410002', 'inverse': tone(n, 800), 'on-inverse': tone(n, 50)
    };
    setVars(P); surface = P.surface;
    ui.dynamic = true;
  } else {
    // Fallback: statische Palette aus dem Stylesheet (nur Hell/Dunkel nachführen)
    const st = document.documentElement.style;
    ['primary', 'on-primary', 'primary-container', 'on-primary-container', 'secondary', 'on-secondary', 'secondary-container', 'on-secondary-container', 'tertiary', 'on-tertiary', 'tertiary-container', 'on-tertiary-container', 'surface', 'on-surface', 'on-surface-variant', 'outline', 'outline-variant', 'sc-lowest', 'sc-low', 'sc', 'sc-high', 'sc-highest', 'error', 'error-container', 'on-error-container', 'inverse', 'on-inverse'].forEach(k => st.removeProperty('--' + k));
    surface = getComputedStyle(document.documentElement).getPropertyValue('--surface').trim() || (dark ? '#0f1512' : '#f6fbf5');
    ui.dynamic = false;
  }
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.setAttribute('content', surface);
  const dc = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DynamicColor;
  if (dc && dc.setBars && /^#[0-9a-f]{6}$/i.test(surface)) { try { dc.setBars({ color: surface, darkIcons: !dark }); } catch (e) { /* ignorieren */ } }
}
async function refreshTheme() {
  const dc = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.DynamicColor;
  let t = null;
  if (dc && dc.get) { try { t = await dc.get(); if (t && t.supported) localStorage.setItem(THEME_KEY, JSON.stringify(t)); } catch (e) { t = null; } }
  if (!t) { try { t = JSON.parse(localStorage.getItem(THEME_KEY) || 'null'); } catch (e) { t = null; } }
  await applyPalette(t);
}
try { applyPalette(JSON.parse(localStorage.getItem(THEME_KEY) || 'null')); } catch (e) { applyPalette(null); }
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', refreshTheme);

/* ---------- Nährwert-Rechnung ---------- */
const zero = () => Object.fromEntries(NUTS.map(n => [n[0], 0]));
function itemVals(it) {
  const f = num(it.grams) / 100, o = {};
  for (const [k] of NUTS) o[k] = (it.p100 && it.p100[k] || 0) * f;
  return o;
}
function sum(items) {
  const t = zero();
  for (const it of items) { const v = itemVals(it); for (const k in t) t[k] += v[k]; }
  return t;
}
const dayEntries = k => state.diary.filter(e => e.date === k);
const dayTotals = k => sum(dayEntries(k).flatMap(e => e.items));
function itemFromAI(r) {
  const g = num(r.grams) > 0 ? num(r.grams) : 100, p = {};
  for (const [k] of NUTS) p[k] = Math.max(0, num(r[k])) * 100 / g;
  return { id: uid(), name: String(r.name || 'Unbekannt').slice(0, 80), grams: Math.round(g), p100: p };
}
function goals() {
  const g = num(state.settings.goal) || 2000;
  return { kcal: g, protein: g * 0.25 / 4, carbs: g * 0.5 / 4, fat: g * 0.25 / 9 };
}

/* ---------- Bibliothek ---------- */
function upsertFood(it) {
  const n = it.name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'food' && l.name.toLowerCase() === n);
  if (ex) { ex.items = [Object.assign(clone(it), { id: ex.items[0].id })]; ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'food', name: it.name.trim(), items: [clone(it)], used: 1, ts: Date.now() });
}
function upsertMeal(name, items) {
  const n = name.trim().toLowerCase();
  const ex = state.library.find(l => l.type === 'meal' && l.name.toLowerCase() === n);
  if (ex) { ex.items = clone(items); ex.used = (ex.used || 0) + 1; ex.ts = Date.now(); }
  else state.library.push({ id: uid(), type: 'meal', name: name.trim(), items: clone(items), used: 1, ts: Date.now() });
}
function searchLibrary(q) {
  q = (q || '').trim().toLowerCase();
  return state.library.filter(l => !q || l.name.toLowerCase().includes(q))
    .sort((a, b) => (b.used || 0) - (a.used || 0) || a.name.localeCompare(b.name));
}
function libSub(l) {
  const t = sum(l.items), g = l.items.reduce((a, i) => a + num(i.grams), 0);
  return `${l.type === 'meal' ? l.items.length + ' Zutaten' : r0(g) + ' g'} · ${r0(t.kcal)} kcal · E ${r0(t.protein)} · K ${r0(t.carbs)} · F ${r0(t.fat)}`;
}
function libList(q, mode) {
  const l = searchLibrary(q);
  if (!l.length) return `<div class="seg empty">${state.library.length ? 'Nichts gefunden.' : 'Noch nichts gespeichert – jede gespeicherte Mahlzeit füllt die Bibliothek automatisch.'}</div>`;
  return l.map(x => mode === 'manage'
    ? `<div class="libitem"><div class="t"><b>${esc(x.name)}</b><span>${libSub(x)}</span></div>${x.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}<button class="iconbtn small press" data-a="libdel" data-id="${x.id}" aria-label="Löschen">${ic('delete')}</button></div>`
    : `<button class="libitem press" data-libadd="${x.id}"><div class="t"><b>${esc(x.name)}</b><span>${libSub(x)}</span></div>${x.type === 'meal' ? '<span class="badge">Gericht</span>' : ''}${ic('add')}</button>`).join('');
}

/* ---------- Foto ---------- */
function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }
async function shrink(dataUrl, max, q) {
  const img = await loadImage(dataUrl);
  const s = Math.min(1, max / Math.max(img.width, img.height));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(img.width * s)); c.height = Math.max(1, Math.round(img.height * s));
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', q);
}
const fileToDataUrl = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
async function pickPhoto(source) {
  const cap = window.Capacitor, cam = cap && cap.Plugins && cap.Plugins.Camera;
  if (cam && cap.isNativePlatform && cap.isNativePlatform()) {
    try {
      const r = await cam.getPhoto({ quality: 85, resultType: 'dataUrl', source: source === 'camera' ? 'CAMERA' : 'PHOTOS', width: 1600, correctOrientation: true });
      return r.dataUrl;
    } catch (e) {
      if (/cancel/i.test(String(e && (e.message || e)))) return null;
      console.warn('Camera plugin failed, falling back', e);
    }
  }
  return new Promise(resolve => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*';
    if (source === 'camera') inp.setAttribute('capture', 'environment');
    inp.onchange = async () => resolve(inp.files[0] ? await fileToDataUrl(inp.files[0]) : null);
    inp.click();
  });
}

/* ---------- Gemini ---------- */
function buildPrompt(text, hasImage) {
  return `Du bist ein erfahrener Ernährungsberater. Analysiere ${hasImage ? 'das Foto der Mahlzeit' : 'die Beschreibung der Mahlzeit'}${hasImage && text ? ' und die Angabe des Nutzers' : ''}.
${text ? 'Angabe des Nutzers (hat Vorrang, v. a. bei Mengen und Zutaten): "' + text + '"\n' : ''}Zerlege die Mahlzeit in die wichtigsten Bestandteile (maximal 8) und schätze realistische Portionsgrößen in Gramm.
Gib die Nährwerte jeweils für die gesamte geschätzte Portion dieses Bestandteils an (NICHT pro 100 g).
Antworte ausschließlich mit JSON in genau diesem Format, Namen auf Deutsch:
{"items":[{"name":"","grams":0,"kcal":0,"protein":0,"carbs":0,"fat":0,"fiber":0,"sugar":0,"sat_fat":0,"sodium":0,"potassium":0,"calcium":0,"iron":0,"magnesium":0,"zinc":0,"vit_a":0,"vit_c":0,"vit_d":0,"vit_b12":0}]}
Einheiten: kcal; protein, carbs, fat, fiber, sugar, sat_fat in g; sodium, potassium, calcium, iron, magnesium, zinc, vit_c in mg; vit_a, vit_d, vit_b12 in µg.
Ist kein Essen erkennbar, antworte {"items":[]}.`;
}
function parseJson(txt) {
  let s = String(txt || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a >= 0 && b > a) s = s.slice(a, b + 1);
  const j = JSON.parse(s);
  return Array.isArray(j) ? j : (j.items || []);
}
async function gemPost(model, body) {
  let r, data = {};
  try {
    r = await fetch(`${API}models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(state.settings.apiKey)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    data = await r.json().catch(() => ({}));
  } catch (e) { return { ok: false, status: 0, data, msg: 'Keine Internetverbindung' }; }
  return { ok: r.ok, status: r.status, data, msg: (data.error && data.error.message) || ('HTTP ' + r.status) };
}
const isQuota = r => r.status === 429 || /quota|RESOURCE_EXHAUSTED|rate.?limit/i.test(r.msg);
const isModelProblem = r => isQuota(r) || r.status === 404 || /not found|not supported|no longer available|deprecated/i.test(r.msg);
function friendly(msg) {
  if (/API key not valid|API_KEY_INVALID|key.*invalid/i.test(msg)) return 'Der API-Key ist ungültig.';
  if (/quota|RESOURCE_EXHAUSTED|rate.?limit/i.test(msg)) return 'Für dieses Modell ist kein freies Kontingent verfügbar.';
  return String(msg).slice(0, 160);
}
async function listModels() {
  let r, data;
  try {
    r = await fetch(`${API}models?pageSize=200&key=${encodeURIComponent(state.settings.apiKey)}`);
    data = await r.json().catch(() => ({}));
  } catch (e) { throw new Error('Keine Internetverbindung'); }
  if (!r.ok) throw new Error(friendly((data.error && data.error.message) || ('HTTP ' + r.status)));
  return (data.models || [])
    .filter(m => /gemini/i.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => m.name.replace(/^models\//, ''));
}
function rank(n) {
  let s = /flash-lite/.test(n) ? 1 : /flash/.test(n) ? 0 : /pro/.test(n) ? 3 : 2;
  if (/preview|exp/.test(n)) s += .5;
  return s;
}
function candidates(all, first) {
  const bad = /image|tts|audio|live|embed|aqa|robotics|computer|gemma|learnlm|veo|imagen|vision/i;
  const list = all.filter(n => !bad.test(n)).sort((a, b) => rank(a) - rank(b) || b.localeCompare(a));
  if (first && all.includes(first)) {
    const i = list.indexOf(first);
    if (i >= 0) list.splice(i, 1);
    list.unshift(first);
  }
  return list.slice(0, 8);
}
async function ping(model) {
  const r = await gemPost(model, { contents: [{ parts: [{ text: 'Antworte nur mit: OK' }] }], generationConfig: { maxOutputTokens: 16 } });
  return r;
}
async function findWorkingModel(first, skip) {
  const all = await listModels();
  ui.models = all.slice().sort();
  let lastQuota = false;
  for (const m of candidates(all, first)) {
    if (m === skip) continue;
    const r = await ping(m);
    if (r.ok) return { model: m };
    if (isQuota(r)) lastQuota = true;
  }
  return { model: null, quota: lastQuota };
}
async function callGemini(imageDataUrl, text) {
  if (!state.settings.apiKey) throw new Error('NOKEY');
  const parts = [];
  if (imageDataUrl) parts.push({ inline_data: { mime_type: 'image/jpeg', data: imageDataUrl.split(',')[1] } });
  parts.push({ text: buildPrompt(text, !!imageDataUrl) });
  const body = { contents: [{ parts }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } };
  let model = state.settings.model || DEFAULT_MODEL;
  let r = await gemPost(model, body);
  if (!r.ok && isModelProblem(r)) {
    let found = null;
    try { found = await findWorkingModel(null, model); } catch (e) { /* Key-Problem: unten melden */ }
    if (found && found.model) {
      state.settings.model = found.model; state.settings.keyOk = true; save();
      toast('Modell gewechselt auf ' + found.model);
      r = await gemPost(found.model, body);
    }
  }
  if (!r.ok) throw new Error(friendly(r.msg));
  const cand = r.data.candidates && r.data.candidates[0];
  const txt = cand && cand.content && cand.content.parts ? cand.content.parts.map(p => p.text || '').join('') : '';
  if (!txt) throw new Error('Leere Antwort der KI');
  return parseJson(txt).map(itemFromAI);
}
async function verifyKey() {
  if (!state.settings.apiKey) { ui.key = { s: 'bad', msg: 'Bitte zuerst einen API-Key eintragen.' }; return updateStatus(); }
  if (ui.key.s === 'checking') return;
  ui.key = { s: 'checking' }; updateStatus();
  try {
    const f = await findWorkingModel(state.settings.model);
    if (f.model) {
      state.settings.model = f.model; state.settings.keyOk = true; save();
      ui.key = { s: 'ok', model: f.model };
      toast('API-Key funktioniert ✓');
    } else {
      state.settings.keyOk = false; save();
      ui.key = { s: f.quota ? 'noquota' : 'bad', msg: 'Für keines der Modelle kam eine Antwort.' };
    }
  } catch (e) {
    state.settings.keyOk = false; save();
    ui.key = { s: 'bad', msg: e.message };
  }
  if (draft && draft.stage === 'settings') renderOverlay(); else updateStatus();
}
function statusInfo() {
  const k = ui.key;
  if (k.s === 'checking') return { cls: 'busy', html: '<div class="mini"></div><div>Prüfe Key und suche ein passendes Modell …<small>Das dauert nur einen Moment.</small></div>' };
  if (k.s === 'ok' || (k.s === 'idle' && state.settings.keyOk && state.settings.apiKey))
    return { cls: 'ok', html: `${ic('check')}<div>API-Key funktioniert ✓<small>Aktives Modell: ${esc(state.settings.model)}</small></div>` };
  if (k.s === 'noquota') return { cls: 'err', html: `${ic('error')}<div>Key ist gültig, aber ohne freies Kontingent<small>Für kein Gemini-Modell ist aktuell Quota frei. Aktiviere in Google AI Studio die Abrechnung oder versuche es später erneut.</small></div>` };
  if (k.s === 'bad') return { cls: 'err', html: `${ic('error')}<div>Das hat nicht geklappt<small>${esc(k.msg || 'Unbekannter Fehler')}</small></div>` };
  return null;
}
function updateStatus() {
  const el = $('#keystatus'); if (!el) return;
  const s = statusInfo();
  el.hidden = !s;
  if (s) { el.className = 'status ' + s.cls; el.innerHTML = s.html; }
}

/* ---------- Startbildschirm ---------- */
function arc(cx, cy, r, a0, a1) {
  const p = a => [cx + r * Math.cos(a * Math.PI / 180), cy + r * Math.sin(a * Math.PI / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0.toFixed(2)} ${y0.toFixed(2)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
function ring(val, goal) {
  const pct = Math.min(val / goal, 1), over = val > goal;
  const prog = pct > 0.004 ? `<path class="prog ${over ? 'over' : ''}" pathLength="1" d="${arc(118, 118, 100, 135, 135 + 270 * pct)}"/>` : '';
  return `<div class="ring"><svg viewBox="0 0 236 236"><path class="track" d="${arc(118, 118, 100, 135, 405)}"/>${prog}</svg>
    <div class="ringtxt"><b>${r0(val)}</b><span>kcal gegessen</span></div></div>`;
}
function greeting() { const h = new Date().getHours(); return h < 5 ? 'Gute Nacht' : h < 11 ? 'Guten Morgen' : h < 18 ? 'Guten Tag' : 'Guten Abend'; }
function streak() {
  let s = 0;
  for (let d = new Date(), i = 0; i < 3650; d = addDays(d, -1), i++) {
    if (dayEntries(dkey(d)).length) s++; else if (s || i > 0) break;
  }
  return s;
}

function renderTop() {
  const s = streak();
  $('#top').innerHTML = `<div class="hello"><small>${greeting()}</small><h1>NutriSnap</h1></div>
    <div class="topact">${s ? `<div class="chip">${ic('fire')}${s}</div>` : ''}<button class="iconbtn tonal press" data-a="settings" aria-label="Einstellungen">${ic('settings')}</button></div>`;
}

function renderHome() {
  const k = ui.date, t = dayTotals(k), g = goals();
  const sel = parseKey(k), mon = addDays(sel, -wdIndex(sel)), today = dkey(new Date());
  const week = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(mon, i), kk = dkey(d);
    return `<button class="day press ${kk === k ? 'sel' : ''} ${kk === today ? 'today' : ''} ${dayEntries(kk).length ? 'has' : ''}" data-a="date" data-date="${kk}"><small>${WD[i]}</small><b>${d.getDate()}</b><i></i></button>`;
  }).join('');
  const tile = (cls, label, v, goal) => `<div class="tile ${cls}"><small>${label}</small><b>${r0(v)} g</b><div class="bar"><i style="width:${Math.min(100, v / goal * 100)}%"></i></div></div>`;
  const micro = MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
  const perMeal = MEALS.map(([id, l]) => {
    const m = sum(dayEntries(k).filter(e => e.meal === id).flatMap(e => e.items));
    return `<div class="mealrow"><span>${l}</span><b>${r0(m.kcal)} kcal</b></div>`;
  }).join('');
  const left = g.kcal - t.kcal;
  const meals = MEALS.map(([id, l]) => {
    const es = dayEntries(k).filter(e => e.meal === id).sort((a, b) => a.ts - b.ts);
    const kc = es.reduce((a, e) => a + sum(e.items).kcal, 0);
    const rows = es.length ? es.map(e => {
      const s = sum(e.items);
      return `<button class="seg press" data-a="edit" data-id="${e.id}">${e.thumb ? `<img class="thumb" src="${e.thumb}" alt="">` : `<div class="thumb">${ic('food')}</div>`}<div class="t"><b>${esc(e.name)}</b><span>E ${r0(s.protein)} g · K ${r0(s.carbs)} g · F ${r0(s.fat)} g</span></div><div class="k">${r0(s.kcal)} <small>kcal</small></div></button>`;
    }).join('') : '<div class="seg empty">Noch nichts eingetragen</div>';
    return `<div class="sechead" style="margin:24px 2px 10px"><div><h2 style="font-size:22px">${l}</h2><small>${es.length ? r0(kc) + ' kcal' : 'leer'}</small></div>
      <button class="iconbtn tonal press" data-a="add" data-meal="${id}" aria-label="${l} hinzufügen">${ic('add')}</button></div><div class="seglist">${rows}</div>`;
  }).join('');
  const title = k === today ? 'Heute' : WDL[wdIndex(sel)];
  return `${state.settings.apiKey ? '' : `<button class="banner press" data-a="settings">${ic('sparkle')}<span>Noch kein Gemini-API-Key hinterlegt – hier tippen und einrichten.</span></button>`}
  <div class="weekhead"><b>${MONL[sel.getMonth()]} ${sel.getFullYear()}</b><div class="btns">
    <button class="iconbtn small press" data-a="shiftweek" data-n="-7" aria-label="Vorherige Woche">${ic('left')}</button>
    <button class="iconbtn small press" data-a="shiftweek" data-n="7" aria-label="Nächste Woche">${ic('right')}</button></div></div>
  <div class="week">${week}</div>
  <div class="pages" id="pages">
    <div class="page"><div class="hero fade">${ring(t.kcal, g.kcal)}<div class="heroline">${left >= 0 ? 'noch ' + r0(left) + ' kcal übrig' : r0(-left) + ' kcal über dem Ziel'} · Ziel ${r0(g.kcal)}</div></div>
      <div class="tiles">${tile('t-p', 'Eiweiß', t.protein, g.protein)}${tile('t-c', 'Kohlenhydrate', t.carbs, g.carbs)}${tile('t-f', 'Fett', t.fat, g.fat)}</div></div>
    <div class="page"><div class="card fade"><h3>Mikronährstoffe</h3><div class="microgrid">${micro}</div></div></div>
    <div class="page"><div class="card fade"><h3>Kalorien pro Mahlzeit</h3>${perMeal}<div class="mealrow"><span>Tagesziel</span><b>${r0(g.kcal)} kcal</b></div></div></div>
  </div>
  <div class="dots"><i class="on"></i><i></i><i></i></div>
  <div class="sechead"><div><h2>${title}</h2><small>${sel.getDate()}. ${MONL[sel.getMonth()]}</small></div></div>${meals}`;
}

function buildFabMenu() {
  $('#fab').innerHTML = ic('add');
  $('#fabmenu').innerHTML = `<div class="menuhint">Mahlzeit hinzufügen</div>
    <button class="fabitem press" data-a="lib">${ic('book')}Aus Bibliothek</button>
    <button class="fabitem press" data-a="desc">${ic('edit')}Beschreiben</button>
    <button class="fabitem press" data-a="gal">${ic('image')}Aus Galerie</button>
    <button class="fabitem press" data-a="cam">${ic('camera')}Foto aufnehmen</button>`;
}
function setFab(on) {
  $('#fab').classList.toggle('open', on); $('#scrim').classList.toggle('on', on);
  $('#fabmenu').classList.toggle('on', on); $('#fabmenu').setAttribute('aria-hidden', String(!on));
  if (!on) ui.meal = null;
}
const fabOpen = () => $('#fab').classList.contains('open');

function render() {
  renderTop();
  $('#view').innerHTML = renderHome();
  const p = $('#pages');
  if (p) p.addEventListener('scroll', () => {
    const i = Math.round(p.scrollLeft / p.clientWidth);
    document.querySelectorAll('.dots i').forEach((d, n) => d.classList.toggle('on', n === i));
  });
}

/* ---------- Dialoge (Overlay) ---------- */
function newDraft(meal) {
  return { stage: 'choose', meal: meal || ui.meal || guessMeal(), date: ui.date, items: [], photo: '', thumb: '', text: '', name: '', editId: null, append: false, saveMeal: false, mealName: '', libq: '' };
}
function guessMeal() { const h = new Date().getHours(); return h < 10 ? 'breakfast' : h < 15 ? 'lunch' : h < 18 ? 'snack' : 'dinner'; }
function openOverlay() { setFab(false); $('#overlay').hidden = false; $('#overlay').scrollTop = 0; renderOverlay(); }
function closeOverlay() { $('#overlay').hidden = true; draft = null; render(); }

const bar = (title, icon = 'back') => `<div class="appbar"><button class="iconbtn tonal press" data-a="back" aria-label="Zurück">${ic(icon)}</button><h1>${title}</h1></div>`;
function mealGroup() {
  return `<div class="btngroup">${MEALS.map(([id, , s]) => `<button class="gbtn ${draft.meal === id ? 'on' : ''}" data-a="setmeal" data-meal="${id}">${s}</button>`).join('')}</div>`;
}
const tf = (label, inner) => `<label class="tf"><span>${label}</span>${inner}</label>`;

function renderOverlay() {
  const d = draft, o = $('#overlay');
  if (!d) return;
  let h = '';
  if (d.stage === 'photo') {
    h = `${bar('Dein Foto', 'close')}<img class="photo" src="${d.photo}" alt="">
    ${tf('Was hast du gegessen? (optional)', `<textarea data-i="text" placeholder="z. B. Pizza Salami, dazu ein kleiner Salat …">${esc(d.text)}</textarea>`)}
    <div class="row"><button class="btn tonal" data-a="analyze" data-skip="1">Überspringen</button><button class="btn" data-a="analyze">${ic('sparkle')}Analysieren</button></div>`;
  } else if (d.stage === 'text') {
    h = `${bar(d.append ? 'Zutat hinzufügen' : 'Mahlzeit beschreiben')}
    ${tf('Beschreibung', `<textarea data-i="text" placeholder="z. B. 2 Spiegeleier, 1 Scheibe Toast mit Butter, ein Glas Orangensaft">${esc(d.text)}</textarea>`)}
    <button class="btn" data-a="analyze" data-textonly="1">${ic('sparkle')}Analysieren</button>`;
  } else if (d.stage === 'loading') {
    h = `${bar('Analysiere …', 'close')}<div class="loader"><i></i></div><p class="center muted">Die KI schätzt Portionen und Nährwerte.</p>`;
  } else if (d.stage === 'library') {
    h = `${bar('Bibliothek')}${tf('Suchen', `<input data-i="libq" value="${esc(d.libq)}" placeholder="Lebensmittel oder Gericht …">`)}
    <div class="seglist" id="liblist">${libList(d.libq, 'pick')}</div>
    <button class="btn" data-a="toreview" ${d.items.length ? '' : 'disabled'}>Fertig (${d.items.length} Zutaten)</button>`;
  } else if (d.stage === 'libmanage') {
    h = `${bar('Bibliothek')}${tf('Suchen', `<input data-i="libq" value="${esc(d.libq)}" placeholder="Suchen …">`)}<div class="seglist" id="liblist">${libList(d.libq, 'manage')}</div>`;
  } else if (d.stage === 'review') {
    const t = sum(d.items);
    h = `${bar(d.editId ? 'Eintrag bearbeiten' : 'Ergebnis', 'close')}
    ${d.photo ? `<img class="photo" style="max-height:220px" src="${d.photo}" alt="">` : ''}
    ${mealGroup()}
    ${tf('Name der Mahlzeit (optional)', `<input data-i="name" value="${esc(d.name)}">`)}
    <div id="items">${d.items.map((it, i) => itemHtml(it, i)).join('') || '<div class="seg empty">Noch keine Zutaten.</div>'}</div>
    <div class="row"><button class="btn tonal small" data-a="addtext">${ic('sparkle')}Zutat (KI)</button><button class="btn tert small" data-a="lib">${ic('book')}Bibliothek</button></div>
    <div class="total" id="total">${totalHtml(t)}</div>
    <details><summary>Alle Nährstoffe</summary><div class="microgrid" id="micros" style="margin-top:10px">${microHtml(t)}</div></details>
    ${d.items.length > 1 ? `<label class="switch"><span>Als Gericht in der Bibliothek speichern</span><input type="checkbox" data-i="savemeal" ${d.saveMeal ? 'checked' : ''}></label>
    ${d.saveMeal ? tf('Name des Gerichts', `<input data-i="mealname" value="${esc(d.mealName || d.name)}">`) : ''}` : ''}
    <button class="btn" data-a="save" ${d.items.length ? '' : 'disabled'}>Speichern</button>
    ${d.editId ? `<button class="btn danger" data-a="delentry">${ic('delete')}Eintrag löschen</button>` : ''}`;
  } else if (d.stage === 'settings') {
    const s = state.settings;
    const opts = ui.models.length ? tf('Modell wählen', `<select data-i="model-select">${ui.models.map(m => `<option ${m === s.model ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select>`) : '';
    h = `${bar('Einstellungen', 'close')}
    <div class="secttl" style="margin-top:8px">Google Gemini</div>
    <label class="tf"><span>API-Key</span><input id="keyinput" type="${ui.showKey ? 'text' : 'password'}" data-i="set" data-f="apiKey" value="${esc(s.apiKey)}" placeholder="AIza…" autocomplete="off" style="padding-right:44px"><button type="button" class="eye press" data-a="eye" aria-label="Key anzeigen">${ic('eye')}</button></label>
    <div class="hint">Kostenlos erstellen unter aistudio.google.com/apikey. Der Key bleibt nur auf diesem Handy.</div>
    <button class="btn" data-a="verify">${ic('check')}Key prüfen</button>
    <div id="keystatus" class="status" hidden></div>
    ${tf('Aktives Modell', `<input data-i="set" data-f="model" value="${esc(s.model)}">`)}${opts}
    <button class="btn tonal small" data-a="models">Verfügbare Modelle laden</button>
    <div class="secttl">Ziele</div>
    ${tf('Tagesziel Kalorien', `<input type="number" inputmode="numeric" data-i="set" data-f="goal" value="${esc(s.goal)}">`)}
    <div class="secttl">Daten</div>
    <button class="libitem press" data-a="libmanage" style="border-radius:28px"><div class="t"><b>Bibliothek verwalten</b><span>${state.library.length} gespeicherte Lebensmittel &amp; Gerichte</span></div>${ic('right')}</button>
    <div class="row"><button class="btn tonal small" data-a="backup-copy">Backup kopieren</button><button class="btn tonal small" data-a="backup-paste">Wiederherstellen</button></div>
    <p class="muted center" style="font-size:13px;margin-top:26px">Farben: ${ui.dynamic ? 'dynamisch nach deinem Hintergrundbild (Material You)' : 'Standard-Palette (dynamische Farben ab Android 12)'}<br>NutriSnap 1.1 · KI-Werte sind Schätzungen</p>`;
  }
  o.innerHTML = `<div class="ov">${h}</div>`;
  updateStatus();
}
function itemHtml(it, i) {
  return `<div class="item"><div class="top"><input data-i="iname" data-idx="${i}" value="${esc(it.name)}" aria-label="Name"><input class="g" type="number" inputmode="decimal" data-i="igrams" data-idx="${i}" value="${r0(it.grams)}" aria-label="Gramm"><span class="muted">g</span><button class="iconbtn small press" data-a="idel" data-idx="${i}" aria-label="Entfernen">${ic('close')}</button></div>
  <div class="nums" id="in${i}">${itemNums(itemVals(it))}</div></div>`;
}
const itemNums = v => `<div class="nchip n-k"><b>${r0(v.kcal)}</b>kcal</div><div class="nchip n-p"><b>${r0(v.protein)}</b>Eiweiß</div><div class="nchip n-c"><b>${r0(v.carbs)}</b>Kohlen.</div><div class="nchip n-f"><b>${r0(v.fat)}</b>Fett</div>`;
const totalHtml = t => `<div class="kc">${r0(t.kcal)} <small>kcal</small></div><div class="sub">Eiweiß ${r0(t.protein)} g · Kohlenhydrate ${r0(t.carbs)} g · Fett ${r0(t.fat)} g</div>`;
const microHtml = t => MICROS.map(([id, l, u]) => `<div class="micro"><span>${l}</span><span>${fmt(t[id], u)}</span></div>`).join('');
function refreshTotals() {
  const t = sum(draft.items);
  const a = $('#total'); if (a) a.innerHTML = totalHtml(t);
  const b = $('#micros'); if (b) b.innerHTML = microHtml(t);
  draft.items.forEach((it, i) => { const e = $('#in' + i); if (e) e.innerHTML = itemNums(itemVals(it)); });
}

async function analyze(skip, textOnly) {
  const d = draft, text = skip ? '' : (d.text || '').trim();
  const useImage = !textOnly && d.photo && !d.append;
  if (textOnly && !text) return toast('Bitte etwas eingeben');
  const prev = d.stage;
  d.stage = 'loading'; renderOverlay();
  try {
    const items = await callGemini(useImage ? d.photo : null, text);
    if (draft !== d) return;
    if (!items.length) { d.stage = prev; renderOverlay(); return toast('Kein Essen erkannt – bitte beschreibe es kurz.'); }
    d.items = d.append ? d.items.concat(items) : items;
    d.append = false; d.text = ''; d.stage = 'review'; renderOverlay();
  } catch (e) {
    if (draft !== d) return;
    d.stage = prev; renderOverlay();
    if (e.message === 'NOKEY') { toast('Bitte zuerst den API-Key eintragen.'); d.stage = 'settings'; renderOverlay(); }
    else toast('Fehler: ' + e.message);
  }
}
function saveDraft() {
  const d = draft;
  if (!d.items.length) return;
  const name = (d.name || '').trim() || d.items.map(i => i.name).join(', ').slice(0, 60);
  const entry = { id: d.editId || uid(), date: d.date, meal: d.meal, name, thumb: d.thumb || '', items: clone(d.items), ts: d.ts || Date.now() };
  const i = d.editId ? state.diary.findIndex(e => e.id === d.editId) : -1;
  if (i >= 0) state.diary[i] = entry; else state.diary.push(entry);
  d.items.forEach(upsertFood);
  if (d.saveMeal && d.items.length > 1) upsertMeal(d.mealName || name, d.items);
  save(); closeOverlay(); toast('Gespeichert');
}
async function photo(src) {
  const meal = ui.meal;
  setFab(false);
  const raw = await pickPhoto(src);
  if (!raw) return;
  try {
    draft = newDraft(meal);
    draft.photo = await shrink(raw, 1024, 0.8);
    draft.thumb = await shrink(raw, 140, 0.6);
    draft.stage = 'photo'; openOverlay();
  } catch (e) { draft = null; toast('Foto konnte nicht geladen werden'); }
}
function goBack() {
  if (!draft) return;
  const s = draft.stage;
  if (s === 'libmanage') { draft.stage = 'settings'; draft.libq = ''; return renderOverlay(); }
  if ((s === 'text' && draft.append) || (s === 'library' && (draft.items.length || draft.editId))) { draft.append = false; draft.stage = 'review'; return renderOverlay(); }
  if (s === 'loading') return;
  closeOverlay();
}

/* ---------- Ereignisse ---------- */
const actions = {
  date(el) { ui.date = el.dataset.date; render(); },
  shiftweek(el) { ui.date = dkey(addDays(parseKey(ui.date), +el.dataset.n)); render(); },
  fab() { if (fabOpen()) setFab(false); else { ui.meal = null; setFab(true); } },
  fabclose() { setFab(false); },
  add(el) { ui.meal = el.dataset.meal; setFab(true); },
  async cam() { await photo('camera'); },
  async gal() { await photo('photos'); },
  desc() { const m = ui.meal; draft = newDraft(m); draft.stage = 'text'; openOverlay(); },
  lib() {
    if (!draft) { const m = ui.meal; draft = newDraft(m); }
    draft.stage = 'library'; openOverlay();
  },
  settings() { setFab(false); draft = newDraft(); draft.stage = 'settings'; openOverlay(); },
  libmanage() { draft.stage = 'libmanage'; draft.libq = ''; renderOverlay(); },
  edit(el) {
    const e = state.diary.find(x => x.id === el.dataset.id); if (!e) return;
    draft = Object.assign(newDraft(e.meal), { stage: 'review', date: e.date, items: clone(e.items), thumb: e.thumb, photo: e.thumb, name: e.name, editId: e.id, ts: e.ts });
    openOverlay();
  },
  back() { goBack(); },
  setmeal(el) { draft.meal = el.dataset.meal; renderOverlay(); },
  toreview() {
    draft.append = false;
    if (!draft.items.length && !draft.editId) return closeOverlay();
    draft.stage = 'review'; renderOverlay();
  },
  addtext() { draft.stage = 'text'; draft.append = true; draft.text = ''; renderOverlay(); },
  analyze(el) { analyze(!!el.dataset.skip, !!el.dataset.textonly); },
  idel(el) { draft.items.splice(+el.dataset.idx, 1); renderOverlay(); },
  save() { saveDraft(); },
  delentry() {
    if (!confirm('Eintrag wirklich löschen?')) return;
    state.diary = state.diary.filter(e => e.id !== draft.editId); save(); closeOverlay();
  },
  libdel(el) {
    if (!confirm('Aus der Bibliothek löschen?')) return;
    state.library = state.library.filter(l => l.id !== el.dataset.id); save(); renderOverlay();
  },
  eye() { ui.showKey = !ui.showKey; const i = $('#keyinput'); if (i) i.type = ui.showKey ? 'text' : 'password'; },
  verify() { verifyKey(); },
  async models() {
    if (!state.settings.apiKey) return toast('Erst den API-Key eintragen');
    try { ui.models = (await listModels()).sort(); toast(ui.models.length + ' Modelle gefunden'); renderOverlay(); }
    catch (e) { toast('Fehler: ' + e.message); }
  },
  async 'backup-copy'() {
    try { await navigator.clipboard.writeText(JSON.stringify(state)); toast('Backup kopiert – z. B. in eine Notiz einfügen'); }
    catch (e) { toast('Kopieren nicht möglich'); }
  },
  'backup-paste'() {
    const t = prompt('Backup-Text hier einfügen (ersetzt alle aktuellen Daten):');
    if (!t) return;
    try {
      const s = JSON.parse(t);
      if (!Array.isArray(s.diary) || !Array.isArray(s.library)) throw new Error('x');
      state = { settings: Object.assign({ apiKey: '', model: DEFAULT_MODEL, goal: 2000, keyOk: false }, s.settings || {}), library: s.library, diary: s.diary };
      save(); render(); renderOverlay(); toast('Backup wiederhergestellt');
    } catch (e) { toast('Das war kein gültiges Backup'); }
  }
};

document.addEventListener('click', e => {
  const libadd = e.target.closest('[data-libadd]');
  if (libadd && draft) {
    const l = state.library.find(x => x.id === libadd.dataset.libadd);
    if (l) {
      l.items.forEach(it => draft.items.push(Object.assign(clone(it), { id: uid() })));
      l.used = (l.used || 0) + 1; save();
      toast('+ ' + l.name); renderOverlay();
    }
    return;
  }
  const el = e.target.closest('[data-a]');
  if (el && actions[el.dataset.a]) actions[el.dataset.a](el, e);
});
document.addEventListener('input', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (!i) return;
  if (i === 'text' && draft) draft.text = t.value;
  else if (i === 'name' && draft) draft.name = t.value;
  else if (i === 'mealname' && draft) draft.mealName = t.value;
  else if (i === 'iname' && draft) draft.items[+t.dataset.idx].name = t.value;
  else if (i === 'igrams' && draft) { draft.items[+t.dataset.idx].grams = num(t.value); refreshTotals(); }
  else if (i === 'libq' && draft) {
    draft.libq = t.value;
    const l = $('#liblist'); if (l) l.innerHTML = libList(t.value, draft.stage === 'libmanage' ? 'manage' : 'pick');
  } else if (i === 'set') {
    const f = t.dataset.f;
    if (f === 'apiKey') { state.settings.apiKey = t.value.trim(); state.settings.keyOk = false; ui.key = { s: 'idle' }; updateStatus(); }
    else if (f === 'goal') state.settings.goal = num(t.value) || 2000;
    else state.settings[f] = t.value.trim();
    save();
  }
});
document.addEventListener('change', e => {
  const t = e.target, i = t.dataset && t.dataset.i;
  if (i === 'savemeal' && draft) { draft.saveMeal = t.checked; renderOverlay(); }
  else if (i === 'model-select') { state.settings.model = t.value; save(); toast('Modell: ' + t.value); }
  else if (i === 'set' && t.dataset.f === 'apiKey' && state.settings.apiKey.length > 20) verifyKey();
});

/* Android-Zurück-Taste */
(function backButton() {
  const cap = window.Capacitor, app = cap && cap.Plugins && cap.Plugins.App;
  if (!app || !app.addListener) return;
  app.addListener('backButton', () => {
    if (!$('#overlay').hidden) return goBack();
    if (fabOpen()) return setFab(false);
    if (app.exitApp) app.exitApp();
  });
  app.addListener('appStateChange', s => { if (s && s.isActive) refreshTheme(); });
})();

window.applySystemTheme = t => { try { localStorage.setItem(THEME_KEY, JSON.stringify(t)); } catch (e) { /* egal */ } applyPalette(t); };
window.__nutrisnap = { get state() { return state; }, get draft() { return draft; }, ui, render, callGemini, saveDraft, sum, actions, applyPalette, verifyKey };

buildFabMenu();
render();
refreshTheme();
})();
